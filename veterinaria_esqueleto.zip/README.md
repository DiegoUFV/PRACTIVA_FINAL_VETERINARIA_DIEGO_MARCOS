# Proyecto Veterinaria

Esqueleto inicial del sistema de gestión para una clínica veterinaria.

- Clases de dominio en `src/clases/`
- Utilidades en `src/utils/`
- Capa de BBDD en `src/db.py`
- Páginas de Streamlit en `pages/`
- Tests básicos en `tests/`
