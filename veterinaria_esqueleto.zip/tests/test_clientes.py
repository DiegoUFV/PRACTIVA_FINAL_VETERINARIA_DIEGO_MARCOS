from src.clases.cliente import Cliente

def test_crear_cliente_basico():
    cliente = Cliente(id_cliente=None, nombre="Test", telefono="600000000")
    assert cliente.nombre == "Test"
