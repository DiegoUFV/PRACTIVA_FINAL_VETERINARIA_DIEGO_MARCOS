from src.clases.mascota import Mascota

def test_crear_mascota_basica():
    mascota = Mascota(id_mascota=None, id_cliente=1, nombre="Firulais", especie="perro")
    assert mascota.especie == "perro"
