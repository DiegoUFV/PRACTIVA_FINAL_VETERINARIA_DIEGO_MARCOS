from datetime import datetime
from src.clases.cita import Cita

def test_crear_cita_basica():
    cita = Cita(
        id_cita=None,
        id_mascota=1,
        id_veterinario=1,
        fecha_hora=datetime.now(),
        motivo="Revisión",
    )
    assert cita.motivo == "Revisión"
