"""Paquete de tests (pytest)."""
