import streamlit as st

st.set_page_config(page_title="Veterinarios", layout="wide")

st.title("Veterinarios")
st.info("Página de Streamlit en modo esqueleto. Aquí luego conectaremos con las clases y la BBDD.")
