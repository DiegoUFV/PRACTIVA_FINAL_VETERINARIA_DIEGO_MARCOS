import streamlit as st

st.set_page_config(page_title="Facturas", layout="wide")

st.title("Facturas")
st.info("Página de Streamlit en modo esqueleto. Aquí luego conectaremos con las clases y la BBDD.")
