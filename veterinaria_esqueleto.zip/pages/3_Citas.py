import streamlit as st

st.set_page_config(page_title="Citas", layout="wide")

st.title("Citas")
st.info("Página de Streamlit en modo esqueleto. Aquí luego conectaremos con las clases y la BBDD.")
