from .validaciones import validar_fecha

def formatear_factura(factura) -> str:
    """Devuelve una representación en texto de la factura (placeholder)."""
    return "FACTURA (esqueleto)"  # luego definiremos el formato real

def exportar_pdf(datos: dict, ruta_salida: str) -> None:
    """Exporta información a PDF (placeholder, sin implementación)."""
    pass
