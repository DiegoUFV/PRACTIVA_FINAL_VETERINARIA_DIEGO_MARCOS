from datetime import datetime

def validar_email(email: str) -> bool:
    """Valida mínimamente el formato de un email (placeholder)."""
    # luego añadiremos una expresión regular
    return True

def validar_fecha(fecha_str: str, formato: str = "%Y-%m-%d") -> bool:
    """Comprueba si una fecha es válida según un formato (placeholder)."""
    try:
        datetime.strptime(fecha_str, formato)
        return True
    except Exception:
        return False
