"""Punto de entrada base para pequeñas pruebas en consola.

No es la app principal (que será Streamlit), pero sirve para probar las clases.
"""

from clases.cliente import Cliente

def main() -> None:
    # pequeña prueba manual (placeholder)
    cliente_demo = Cliente(
        id_cliente=None,
        nombre="Cliente Demo",
        telefono="600000000",
        email="demo@example.com",
    )
    print("Cliente de prueba creado (solo esqueleto):", cliente_demo)

if __name__ == "__main__":
    main()
