"""Paquete principal de la aplicación de veterinaria."""
