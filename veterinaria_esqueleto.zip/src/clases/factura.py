from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import List

@dataclass
class LineaFactura:
    """Una línea dentro de una factura (concepto, cantidad, precio)."""

    descripcion: str
    cantidad: float
    precio_unitario: float

    @property
    def total(self) -> float:
        """Importe total de esta línea (placeholder)."""
        return self.cantidad * self.precio_unitario

@dataclass
class Factura:
    """Representa una factura emitida al cliente."""

    id_factura: int | None
    id_cliente: int
    id_mascota: int
    fecha_emision: datetime
    lineas: List[LineaFactura] = field(default_factory=list)
    iva: float = 0.21  # 21% por defecto en España

    def anadir_linea(self, linea: LineaFactura) -> None:
        """Añade una nueva línea a la factura."""
        pass

    @property
    def base_imponible(self) -> float:
        """Suma de todas las líneas sin IVA (placeholder)."""
        return 0.0

    @property
    def importe_iva(self) -> float:
        """Importe del IVA calculado sobre la base (placeholder)."""
        return 0.0

    @property
    def total(self) -> float:
        """Total factura (base + IVA) (placeholder)."""
        return 0.0
