from dataclasses import dataclass
from typing import Optional

@dataclass
class Veterinario:
    """Datos básicos del veterinario."""

    id_veterinario: int | None
    nombre: str
    colegiado: Optional[str] = None
    especialidad: Optional[str] = None
    email: Optional[str] = None
    telefono: Optional[str] = None

    def esta_disponible(self, fecha_hora) -> bool:
        """Devuelve si el veterinario está disponible en esa fecha/hora (placeholder)."""
        return True
