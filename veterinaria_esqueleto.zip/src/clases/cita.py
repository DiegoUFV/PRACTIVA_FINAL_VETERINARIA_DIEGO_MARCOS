from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

class EstadoCita(str, Enum):
    PENDIENTE = "pendiente"
    COMPLETADA = "completada"
    CANCELADA = "cancelada"

@dataclass
class Cita:
    """Representa una cita entre una mascota y un veterinario."""

    id_cita: int | None
    id_mascota: int
    id_veterinario: int
    fecha_hora: datetime
    motivo: str
    estado: EstadoCita = EstadoCita.PENDIENTE

    def marcar_completada(self) -> None:
        """Marca la cita como completada (placeholder)."""
        pass

    def cancelar(self, motivo_cancelacion: str | None = None) -> None:
        """Cancela la cita (placeholder)."""
        pass
