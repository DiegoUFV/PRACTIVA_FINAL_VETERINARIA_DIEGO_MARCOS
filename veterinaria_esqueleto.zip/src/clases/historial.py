from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import List

@dataclass
class EntradaHistorial:
    """Entrada de historial para una mascota (consulta, tratamiento, vacuna, etc.)."""

    id_entrada: int | None
    id_mascota: int
    fecha: datetime
    descripcion: str
    veterinario: str | None = None
    notas: str | None = None

@dataclass
class HistorialClinico:
    """Conjunto de entradas asociadas a una mascota."""

    id_mascota: int
    entradas: List[EntradaHistorial] = field(default_factory=list)

    def anadir_entrada(self, entrada: EntradaHistorial) -> None:
        """Agrega una nueva entrada al historial (placeholder)."""
        pass

    def obtener_entradas_ordenadas(self) -> List[EntradaHistorial]:
        """Devuelve las entradas ordenadas por fecha (placeholder)."""
        return self.entradas
