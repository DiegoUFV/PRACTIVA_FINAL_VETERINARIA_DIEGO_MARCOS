from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .mascota import Mascota  # import circular controlado por typing en tiempo de ejecución

@dataclass
class Cliente:
    """Representa al propietario de una o varias mascotas."""

    id_cliente: int | None
    nombre: str
    telefono: str
    email: Optional[str] = None
    direccion: Optional[str] = None
    mascotas: List[Mascota] = field(default_factory=list)

    def anadir_mascota(self, mascota: Mascota) -> None:
        """Asocia una mascota a este cliente."""
        pass

    def eliminar_mascota(self, id_mascota: int) -> None:
        """Elimina una mascota de la lista (sin borrarla de BBDD todavía)."""
        pass

    @classmethod
    def desde_fila(cls, fila: tuple) -> "Cliente":
        """Crea un cliente a partir de una fila devuelta por la BBDD (placeholder)."""
        # más adelante mapearemos los índices concretos
        pass
