from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from typing import Optional

@dataclass
class Mascota:
    """Representa una mascota del cliente."""

    id_mascota: int | None
    id_cliente: int
    nombre: str
    especie: str        # perro, gato, etc.
    raza: Optional[str] = None
    fecha_nacimiento: Optional[date] = None
    observaciones: Optional[str] = None

    def calcular_edad(self) -> Optional[int]:
        """Devuelve la edad aproximada en años (placeholder)."""
        pass

    @classmethod
    def desde_fila(cls, fila: tuple) -> "Mascota":
        """Crea una mascota a partir de una fila de la BBDD (placeholder)."""
        pass
