from typing import Any, Iterable

class DB:
    """Capa muy simple para gestionar la conexión y operaciones básicas con SQLite.

    Más adelante aquí irán:
    - Conexión real a sqlite3
    - Creación de tablas
    - Operaciones CRUD genéricas
    """

    def __init__(self, ruta_bd: str = "veterinaria.db") -> None:
        self.ruta_bd = ruta_bd

    def conectar(self) -> Any:
        """Devuelve una conexión a la base de datos (placeholder)."""
        pass

    def crear_tablas(self) -> None:
        """Crea las tablas necesarias si no existen (placeholder)."""
        pass

    def ejecutar(self, sql: str, params: Iterable[Any] | None = None) -> None:
        """Ejecuta un comando de escritura (INSERT, UPDATE, DELETE)."""
        pass

    def consultar(self, sql: str, params: Iterable[Any] | None = None) -> list[tuple]:
        """Ejecuta una consulta SELECT y devuelve filas (placeholder)."""
        return []
